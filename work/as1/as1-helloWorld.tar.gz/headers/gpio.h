#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//Write data to file 
void echo(int data);

// Function for sleeping before echoing
void wait(long seconds);

//Read data from a from Pin 
char*  readFromFileToScreen(char * fileName);