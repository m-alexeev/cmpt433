#include <stdio.h>
#include <stdlib.h>
#include <time.h>


//Sleep for n seconds (can also do fractions of a second)
void wait(long seconds);

