#ifndef UTILS_H_
#define UTILS_H_ 

//Sleep for n seconds (can also do fractions of a second)
void wait(long seconds, long nanoseconds);


#endif 