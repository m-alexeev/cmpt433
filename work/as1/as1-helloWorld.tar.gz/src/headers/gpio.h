#ifndef GPIO_H_
#define GPIO_H_

//Write data to file 
void echo(int data);


//Read data from a from Pin 
char*  readFromFileToScreen(char * fileName);

#endif